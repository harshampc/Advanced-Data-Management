/*
 * Chigullapally Sriharsha
 * 15111013
 */


#include <iostream>
#include <fstream>
using namespace std;



int main()
{
    string inputfilename,outputfilename;
    
    cout<<"enter input file name"<<"\n";
    cin>>inputfilename;
    cout<<"enter ouput file name"<<"\n";
    cin>>outputfilename;
    
    ifstream read(inputfilename.c_str(), ios::in);

    ofstream write(outputfilename.c_str(), ios::out | ios::trunc);

    int prevsrc, prevdtn, cursrc, curdtn;
    int count;
    char ch;

    read >> prevsrc >> ch >> prevdtn;
    
    //first line, first entry
    if(prevsrc==1&&prevdtn==1)
        {
            write<< "[1]";
        }
    else if(prevsrc==1)
        {
            write<< "[0]";write<<" "<<prevdtn-1;
        }
    else
	{
		for(int i=1;i<prevsrc;i++)
                {
                    write<<"[0]"<<"\n";
                }
		if(prevdtn==1)
		{
		    write<< "[1]";
		}
	    	else 
		{
		    write<< "[0]";write<<" "<<prevdtn-1;
		}
		
	}
        
    // comma will be read into ch, not used anywhere
    read >> cursrc >> ch >> curdtn;
    
    count=1;
    
    while(!read.eof())
    {
                
            while(cursrc==prevsrc)//same row
            {
                
                
                if(curdtn==prevdtn+1)
                {
                    count++; //counting number of occurences
                }
                    
                else
                {
                    write<<" "<<count; // write count of prev bits
                    if(read.eof()) break; //break if there are no more entries to be read
                    write<<" "<<curdtn-prevdtn-1;//now, count of elapsed entries
                    count=1;
                    
                }
                
                prevsrc=cursrc;prevdtn=curdtn;
                read >> cursrc >> ch >> curdtn;
            }
        
        if(read.eof()) break;
        write<<" "<<count; 
        write<<"\n";
        
        
        //if next row is non empty
        if(cursrc==prevsrc+1&&curdtn==1)
        {
            write<< "[1]";
        }
        else//if next row(s) is(are) empty
        {
            if(cursrc==prevsrc+1)
            {
                write<< "[0]";write<<" "<<curdtn-1;
            }
            else
            {
                for(int i=prevsrc+1;i<cursrc;i++)
                {
                    write<<"[0]"<<"\n";
                }
                write<< "[0]";write<<" "<<curdtn-1;
            }
            
        }
        
        prevsrc=cursrc;prevdtn=curdtn;
        read >> cursrc >> ch >> curdtn;
    
        count=1;
        
        //repeat for all rows, i.e, until all entries are read
    }
    
   
    read.close();
    write.close();
    cout<<"\ndone\n";
    return 0;
}
