/* 
 * Chigullapally Sriharsha
 * 15111013
*/


#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

//this will hold lengths, i.e actual entries of compressed matrix
typedef struct ListNode
{
    int bit;
    int length;
    struct ListNode* right;
} listnode;

//this will hold pointers to linked lists of listnodes
typedef struct Node
{
    struct Node* down;
    struct ListNode* right;
} node;

//this will create a 'list of lists' structure by filling into it compressed matrices
node* readinput(string filename)
{
    ifstream read(filename.c_str(), ios::in);
    node *head,*prev,*cur;
    listnode *headl,*prevl,*curl;
    
    int bit,length;
    char ch;
    string line;
    
    prev = new node;
    prev->down = NULL;
    prev->right = NULL;
    head =prev;//head is head to list of lists
    
    while(!read.eof())
    {
        cur = new node;
        cur->down=NULL;
        cur->right=NULL;
         
        getline(read, line);
        istringstream readline(line);
        readline>>ch>>bit>>ch;
        
        prevl = new listnode;
        headl= prevl;//this is head to list(of lengths along with bits)
        while(readline>>length)
        {
            curl = new listnode;
            curl->length = length; 
            curl->bit= bit; 
            curl->right=NULL;
            bit=(bit==0)?1:0;//toggle the bit as you move to next length
            prevl->right = curl;
            prevl=curl;
        }
        cur->right = headl->right;//set an entry of 'list of lists' to head of list that is created just now
        prev->down = cur;
        prev = cur;
        
    }
    
    head = head->down;//setting the head of 'list of lists'
     
    return head;
}

int getlength(node *head)//gives length of 'list of lists' i.e, number of linked lists = no. of rows
{
    int length=0;
    while(head->down!=NULL)
    {
        length++;
        head=head->down;
    }
    
    return length+1;
}

//returns bit at particular location(x,y) in matrix given by pointer head
int getbit(node *head,int x, int y)
{
    
    int bit;
    listnode *curl;
    //going to particular row
    while(x>0)
    {
        head=head->down;
        x--;        
    }
    
    curl=head->right;
    
    y=y+1;
    
    //empty row
    if(curl==NULL)
        bit= 0;
    else
    {
        // go to particular listnode until you reach required column
        y=y-curl->length;
        while(y>0&&curl->right!=NULL)
        {
            curl=curl->right;
            y=y-curl->length;
        }
        if(y>0)
            bit=0;
        else
            bit=curl->bit;
    }
    
    return bit;
}

int main()
{

    string inputfilename1,inputfilename2,outputfilename;
    cout<<"enter first input file name"<<"\n";
    cin>>inputfilename1;
    cout<<"enter second input file name"<<"\n";
    cin>>inputfilename2;
    
    
    node *inp1, *inp2;
    
    inp1 = readinput(inputfilename1);//axb=axa
    inp2 = readinput(inputfilename2);//bxc=bxb
    
    int length = getlength(inp1);//dimensions of matrix
    
    int swtch;
    
    label:
    
    cout<<"Enter 1 to store in memory and display on console, 2 to store in file\n";
    
    cin>>swtch;
    
    if(swtch==1)
    {
        int result[length][length];
        //performing multiplication and storing results in an array
        for(int i=0;i<length;++i)
        {
            for(int j=0;j<length;++j)
            {
                result[i][j]=0;
                for(int k=0;k<length;++k)
                    result[i][j]=(result[i][j]+(getbit(inp1,i,k)*getbit(inp2,k,j)))%2;
            }
        }
        //printing result array
        for (int i = 0; i < length; i++)
        {
            for (int j = 0; j < length; j++)
            {
                cout << result[i][j]<<" ";
            }
            cout << "\n";
        }


	//format 2: 1 for non-zero resultbit and 0 for zero resultbit

	cout<<"\nformat 2:\n";
	for(int i=0;i<length;++i)
        {
            for(int j=0;j<length;++j)
            {
                result[i][j]=0;
                for(int k=0;k<length;++k)
                    {
			result[i][j]=(result[i][j]+(getbit(inp1,i,k)*getbit(inp2,k,j)));
		        if(result[i][j]==1) break;
		    }
            }
        }
        //printing result array
        for (int i = 0; i < length; i++)
        {
            for (int j = 0; j < length; j++)
            {
                cout << result[i][j]<<" ";
            }
            cout << "\n";
        }

	
    }
    
    else if(swtch==2)
    {
    cout<<"enter ouput file name"<<"\n";
    cin>>outputfilename;
   
    ofstream write(outputfilename.c_str(), ios::out | ios::trunc);
    //performing multiplication and storing results to file
    for(int i=0;i<length;++i)
        {
            for(int j=0;j<length;++j)
            {
                int resultbit=0;
                for(int k=0;k<length;++k)
                    resultbit=(resultbit+(getbit(inp1,i,k)*getbit(inp2,k,j)))%2;
                write<<resultbit<<" ";
            }
            write<<"\n";
        }

	write<<"\n\nformat 2:\n";
	//format 2
        string outputfilename2;
	cout<<"\nenter output file name for format 2:\n";
        cin>>outputfilename2;
        ofstream write2(outputfilename2.c_str(), ios::out | ios::trunc);
        for(int i=0;i<length;++i)
        {
            for(int j=0;j<length;++j)
            {
                int resultbit=0;
                for(int k=0;k<length;++k)
                    resultbit=(resultbit+(getbit(inp1,i,k)*getbit(inp2,k,j)));
                if(resultbit>=1) write2<<"1"<<" ";
		else write2<<"0"<<" ";
            }
            write2<<"\n";
        }

	write2.close();
	write.close();
    }
    else
        {
            cout<<"invalid input\n";
            goto label;
        }

    
    
    
    cout<<"\ndone\n";
    
    return 0;
}
